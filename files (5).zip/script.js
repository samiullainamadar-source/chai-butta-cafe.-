// Small JS: search and filter
document.addEventListener('DOMContentLoaded', () => {
  const search = document.getElementById('search');
  const filter = document.getElementById('categoryFilter');
  const printBtn = document.getElementById('printBtn');
  const sections = Array.from(document.querySelectorAll('.menu-section'));

  function applyFilter(){
    const q = search.value.trim().toLowerCase();
    const cat = filter.value.toLowerCase();

    sections.forEach(section => {
      const sectionCat = section.dataset.category ? section.dataset.category.toLowerCase() : '';
      // If category filter and not matching, hide whole section
      if(cat !== 'all' && cat !== sectionCat){
        section.style.display = 'none';
        return;
      }
      // Otherwise test items text
      const items = Array.from(section.querySelectorAll('li'));
      let anyVisible = false;
      items.forEach(li => {
        const text = li.innerText.toLowerCase();
        const visible = text.includes(q);
        li.style.display = visible ? '' : 'none';
        if(visible) anyVisible = true;
      });
      section.style.display = anyVisible ? '' : 'none';
    });
  }

  search.addEventListener('input', applyFilter);
  filter.addEventListener('change', applyFilter);

  printBtn.addEventListener('click', () => window.print());
});